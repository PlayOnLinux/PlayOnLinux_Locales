<h2>Mandriva</h2>
<p>PlayOnLinux finns tillgänglig för din distribution/p>
<p><a href="http://fr2.rpmfind.net/linux/rpm2html/search.php?query=playonlinux&amp;system=&amp;arch=">Klicka här</a> för att få mer information.</p>

