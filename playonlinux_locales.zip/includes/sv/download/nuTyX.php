<h2>NuTyx</h2>
<p>Skriv följande kommando</p>
<div class="codeconsole"><code>get playonlinux</code></div>
