<h2>OpenSUSE</h2>
<p>Gå till den här sidan : <a href="http://packman.links2linux.de/package/PlayOnLinux">http://packman.links2linux.de/package/PlayOnLinux</a></p>
