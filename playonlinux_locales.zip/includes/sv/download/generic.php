<h2>Generiskt paket</h2>
<h3>.tar.gz filer :</h3>
<p>Du behöver bara packa upp dessa filer och köra "./playonlinux". PlayOnLinux är skrivet i programmeringsspråket Python, så det behöver inte kompileras.</p>
<!-- Last version : <?php include($racine."/script_files/version2.php"); ?> -->
<p>PlayOnLinux : <a href="<?php echo $url; ?>/script_files/PlayOnLinux/<?php echo $version; ?>/PlayOnLinux_<?php echo $version; ?>.tar.gz">PlayOnLinux_<?php echo $version; ?>.tar.gz</a></p>
