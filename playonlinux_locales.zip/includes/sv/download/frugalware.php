<h2>Frugalware</h2>
<p>Skriv bara följande kommando</p>
<div class="codeconsole"><code>pacman-g2 -S playonlinux</code></div>
