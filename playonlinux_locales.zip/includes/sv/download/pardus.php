<h2>Pardus</h2>
<h3>Installera PlayOnLinux på Pardus </h3>
<p>Lägg till Pardus officiella contrib-förråd</p>
<div class="codeconsole" ><code>sudo pisi ar contrib-2008 http://paketler.pardus.org.tr/contrib-2008/pisi-index.xml.bz2</code></div>
<p>Använd sedan detta kommando för att installera PlayOnLinux</p>
<div class="codeconsole" ><code>sudo pisi it playonlinux</code></div>
