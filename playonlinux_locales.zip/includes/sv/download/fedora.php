<h2>Fedora</h2>
<p>Gå <a href="http://rpm.playonlinux.com/">hit</a> och installera playonlinux-yum paketet.</p>
