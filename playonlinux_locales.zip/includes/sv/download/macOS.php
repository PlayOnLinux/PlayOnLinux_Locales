<h2>Mac OS X (endast Intel)</h2>
<p>Hämta följande fil</p>
<p><a href='<?php echo $url; ?>/script_files/PlayOnMac/PlayOnMac-<?php include($racine."/script_files/version_mac.php"); ?>.tar.gz'>Klicka här för att hämta PlayOnMac</a></p>
