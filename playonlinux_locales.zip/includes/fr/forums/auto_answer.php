Bonjour,<br /><br />

Ceci est une réponse semi-automatique. Elle permet aux modérateurs du forum d'éviter de répêter les même choses.<br /><br />

Votre topic a été fermé car il ne respecte pas la <a href='/fr/terms.html'>charte du site</a><br /><br />

Merci de prendre conaissance de cette <a href='/fr/terms.html'>charte</a>.<br /><br />

Je reste à disposition en cas de questions.<br /><br />
