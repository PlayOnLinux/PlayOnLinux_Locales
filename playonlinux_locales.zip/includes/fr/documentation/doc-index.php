<h1>Documentation de <?php echo $website_name; ?></h1>
<h2>Documentation du logiciel</h2>
<p><a href="manual.html">Manuel d'utilisation</a><br />
<a href="faq.html">Foire aux questions</a></p>


<h2>Documentation du scripteur</h2>
<p><a href="dev-documentation-1.html">Chapitre 1 : Se familiariser avec le bash</a><br />
<a href="dev-documentation-2.html">Chapitre 2 : Les fonctions de base</a><br />
<a href="dev-documentation-3.html">Chapitre 3 : Les variables</a><br />
<a href="dev-documentation-4.html">Chapitre 4 : Les conditions</a><br />
<a href="dev-documentation-5.html">Chapitre 5 : Wine</a><br />
<a href="dev-documentation-6.html">Chapitre 6 : Le système de fichier</a><br />
<a href="dev-documentation-7.html">Chapitre 7 : Supports d'installation</a><br />
<a href="dev-documentation-8.html">Chapitre 8 : Votre premier vrai script</a><br />
<a href="dev-documentation-9.html">Chapitre 9 : Standardisation des scripts, partie 1/2</a><br />
<a href="dev-documentation-10.html">Chapitre 10 : Standardisation des scripts, partie 2/2</a><br />
<a href="dev-documentation-11.html">Chapitre 11 : Annexe : Liste des fonctions</a><br />

