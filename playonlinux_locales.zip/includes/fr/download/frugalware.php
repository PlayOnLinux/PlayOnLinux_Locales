<h2>Frugalware</h2>
<p>Tapez la commande suivante</p>
<div class="codeconsole"><code>pacman-g2 -S playonlinux</code></div>
