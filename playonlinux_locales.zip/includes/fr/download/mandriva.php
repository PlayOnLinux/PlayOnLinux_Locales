<h2>Mandriva</h2>
<p>PlayOnLinux est déjà disponible dans votre distribution.</p>
<p><a href="http://fr2.rpmfind.net/linux/rpm2html/search.php?query=playonlinux&amp;system=&amp;arch=">Cliquez ici</a> pour plus d'informations.</p>

