<h2>PCLinuxOS</h2>
<p>Vous pouvez télécharger un paquet ici : <a href="http://pclinuxos.bluefusion.hu/apt/pclinuxos/PlayOnLinux/">http://pclinuxos.bluefusion.hu/apt/pclinuxos/PlayOnLinux/</a></p>

