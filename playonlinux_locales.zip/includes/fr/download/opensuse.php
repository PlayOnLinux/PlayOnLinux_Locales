<h2>OpenSUSE</h2>
<p>Allez voir cette page : <a href="http://packman.links2linux.de/package/PlayOnLinux">http://packman.links2linux.de/package/PlayOnLinux</a></p>
