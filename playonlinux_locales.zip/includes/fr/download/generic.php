<h2>Paquets génériques</h2>
<h3>Fichiers .tar.gz</h3>
<p>Vos devez extraire ces fichiers et éxéctuer "./playonlinux".</p>
<!-- Last version : <?php include($racine."/script_files/version2.php"); ?> -->
<p>PlayOnLinux : <a href="<?php echo $url; ?>/script_files/PlayOnLinux/<?php echo $version; ?>/PlayOnLinux_<?php echo $version; ?>.tar.gz">PlayOnLinux_<?php echo $version; ?>.tar.gz</a></p>
