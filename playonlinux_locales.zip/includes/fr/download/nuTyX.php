<h2>NuTyx</h2>
<p>Tapez la commande suivante :</p>
<div class="codeconsole"><code>get playonlinux</code></div>
