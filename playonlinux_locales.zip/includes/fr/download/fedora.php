<h2>Fedora</h2>
<p>Rendez-vous <a href="http://rpm.playonlinux.com/">ici</a> et installez le paquet playonlinux-yum</p>
