// part by ptinou
