// Part by ptinou
