<h2>Mac OS X (Только Intel)</h2>
<p>Загрузите этот файл</p>
<p><a href='<?php echo $url; ?>/script_files/PlayOnMac/PlayOnMac-<?php include($racine."/script_files/version_mac.php"); ?>.tar.gz'>Щёлкните здесь для загрузки PlayOnMac</a></p>
