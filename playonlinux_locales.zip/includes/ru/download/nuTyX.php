<h2>NuTyx</h2>
<p>Выполните эту команду</p>
<div class="codeconsole"><code>get playonlinux</code></div>
