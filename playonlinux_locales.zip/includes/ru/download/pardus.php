<h2>Pardus</h2>
<h3>Для установки PlayOnLinux на Pardus </h3>
<p>Добавьте официальный contrib-репозиторий Pardus</p>
<div class="codeconsole" ><code>sudo pisi ar contrib-2008 http://paketler.pardus.org.tr/contrib-2008/pisi-index.xml.bz2</code></div>
<p>Затем выполните эту команду для установки Playonlinux</p>
<div class="codeconsole" ><code>sudo pisi it playonlinux</code></div>
