<h2>PCLinuxOS</h2>
<p>Вы можете загрузить пакет отсюда : <a href="http://pclinuxos.bluefusion.hu/apt/pclinuxos/PlayOnLinux/">http://pclinuxos.bluefusion.hu/apt/pclinuxos/PlayOnLinux/</a></p>

