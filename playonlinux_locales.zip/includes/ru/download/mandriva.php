<h2>Mandriva</h2>
<p>PlayOnLinux доступен для вашего дистрибутива</p>
<p><a href="http://fr2.rpmfind.net/linux/rpm2html/search.php?query=playonlinux&amp;system=&amp;arch=">Щёлкните здесь</a> для получения информации.</p>

