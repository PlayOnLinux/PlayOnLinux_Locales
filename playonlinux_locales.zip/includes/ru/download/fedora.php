<h2>Fedora</h2>
<p>Перейдите по <a href="http://rpm.playonlinux.com/">ссылке</a> и установите пакет playonlinux-yum.</p>
