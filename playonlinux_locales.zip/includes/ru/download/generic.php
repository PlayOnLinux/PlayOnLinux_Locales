<h2>Скомпилированный пакет</h2>
<h3>.tar.gz файл :</h3>
<p>Вам нужно просто извлечь этот файл и выполнить "./playonlinux". PlayOnLinux написан на python, так что вам не нужно ничего компилировать.</p>
<!-- Last version : <?php include($racine."/script_files/version2.php"); ?> -->
<p>PlayOnLinux : <a href="<?php echo $url; ?>/script_files/PlayOnLinux/<?php echo $version; ?>/PlayOnLinux_<?php echo $version; ?>.tar.gz">PlayOnLinux_<?php echo $version; ?>.tar.gz</a></p>
