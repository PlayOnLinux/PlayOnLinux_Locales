<h2>OpenSUSE</h2>
<p>Перейдите по этой ссылке : <a href="http://packman.links2linux.de/package/PlayOnLinux">http://packman.links2linux.de/package/PlayOnLinux</a></p>
