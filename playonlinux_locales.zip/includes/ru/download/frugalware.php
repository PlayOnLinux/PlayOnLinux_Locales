<h2>Frugalware</h2>
<p>Просто выполните следующую команду</p>
<div class="codeconsole"><code>pacman-g2 -S playonlinux</code></div>
