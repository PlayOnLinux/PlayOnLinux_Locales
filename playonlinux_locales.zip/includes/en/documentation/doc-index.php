<h1><?php echo $website_name; ?> documentation</h1>
<h2>Softwares' documentation</h2>
<p><a href="manual.html">Manual</a><br />
Soon... Frequently Asked Questions here</p>

<h2>Scriptwriter's documentation</h2>
<p><a href="dev-documentation-1.html">Chapter 1: Getting to know Bash</a><br />
<a href="dev-documentation-2.html">Chapter 2: Basic functions</a><br />
<a href="dev-documentation-3.html">Chapter 3: Variables</a><br />
<a href="dev-documentation-4.html">Chapter 4: Conditions</a><br />
<a href="dev-documentation-5.html">Chapter 5: Wine</a><br />
<a href="dev-documentation-6.html">Chapter 6: The file system</a><br />
<a href="dev-documentation-7.html">Chapter 7: Installation media</a><br />
<a href="dev-documentation-8.html">Chapter 8: My first real script</a><br />
<a href="dev-documentation-9.html">Chapter 9: Standardization</a><br />
<a href="dev-documentation-10.html">Chapter 10: Scripts translation</a><br />
<a href="dev-documentation-11.html">Chapter 11: Annex: List of functions</a><br />

