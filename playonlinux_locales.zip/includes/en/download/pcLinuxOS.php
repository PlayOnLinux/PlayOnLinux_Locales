<h2>PCLinuxOS</h2>
<p>You can download a package here: <a href="http://pclinuxos.bluefusion.hu/apt/pclinuxos/PlayOnLinux/">http://pclinuxos.bluefusion.hu/apt/pclinuxos/PlayOnLinux/</a></p>

