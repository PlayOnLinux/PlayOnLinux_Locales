<h2>Gentoo</h2>
<?php /*

<h3>Ajouter le Sunrise Overlay</h3>
<p>Sunrise Overlay contient certains ebuilds fraichement créés et donc pas encore présents dans le dépôt officiel. Layman permet d'utiliser simplement des overlays. Il faut donc installer layman et ajouter sunrise :</p>
<div class="codeconsole" ><code>emerge -av layman<br />
echo "source /usr/portage/local/layman/make.conf" >> /etc/make.conf<br />
layman -f -a sunrise</code></div>

<h3>Installer PlayOnLinux</h3>
*/
?>
<p>To install PlayOnLinux, type the following command:</p>
<div class="codeconsole" >emerge -av playonlinux</code></div>

