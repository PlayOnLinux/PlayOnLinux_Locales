<h2>Fedora</h2>
<p>Go <a href="http://rpm.playonlinux.com/">here</a> and install the playonlinux-yum package.</p>
