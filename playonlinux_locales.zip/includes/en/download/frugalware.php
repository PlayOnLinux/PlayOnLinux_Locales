<h2>Frugalware</h2>
<p>Just type the following command:</p>
<div class="codeconsole"><code>pacman-g2 -S playonlinux</code></div>
