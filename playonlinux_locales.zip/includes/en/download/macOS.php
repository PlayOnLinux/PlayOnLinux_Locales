<h2>Mac OS X (Intel Only)</h2>
<p>Download the following file:</p>
<p><a href='<?php echo $url; ?>/script_files/PlayOnMac/PlayOnMac-<?php include($racine."/script_files/version_mac.php"); ?>.tar.gz'>Click here to download PlayOnMac</a></p>
