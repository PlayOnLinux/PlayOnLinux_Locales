<h2>Mandriva</h2>
<p>PlayOnLinux is available in your distro.</p>
<p><a href="http://fr2.rpmfind.net/linux/rpm2html/search.php?query=playonlinux&amp;system=&amp;arch=">Click here</a> to get more information.</p>

