<h2>Pardus</h2>
<h3>To install PlayOnLinux on Pardus </h3>
<p>Add the official contrib repository of Pardus:</p>
<div class="codeconsole" ><code>sudo pisi ar contrib-2008 http://paketler.pardus.org.tr/contrib-2008/pisi-index.xml.bz2</code></div>
<p>Then use this command to install Playonlinux:</p>
<div class="codeconsole" ><code>sudo pisi it playonlinux</code></div>
