<h1>Installing PlayOnLinux</h1>
<p>As root (or with sudo), type the following command:</p>
<div class="codeconsole"><code>pacman -Syu playonlinux</code></div>
