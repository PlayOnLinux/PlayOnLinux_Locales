<h2>Sabayon</h2>
<p>To install PlayOnLinux, type the following command:</p>
<div class="codeconsole" >equo install playonlinux</code></div>

