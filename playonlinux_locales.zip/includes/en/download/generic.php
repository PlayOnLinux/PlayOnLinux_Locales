<h2>Generic package</h2>
<h3>.tar.gz files:</h3>
<p>You just have to extract these files and run "./playonlinux". PlayOnLinux is written in Python, so you have nothing to build, but Python must be installed first.</p>
<!-- Last version : <?php include($racine."/script_files/version2.php"); ?> -->
<p>PlayOnLinux: <a href="<?php echo $url; ?>/script_files/PlayOnLinux/<?php echo $version; ?>/PlayOnLinux_<?php echo $version; ?>.tar.gz">PlayOnLinux_<?php echo $version; ?>.tar.gz</a></p>
