<h2>OpenSUSE</h2>
<p>Just go to this page: <a href="http://packman.links2linux.de/package/PlayOnLinux">http://packman.links2linux.de/package/PlayOnLinux</a></p>
