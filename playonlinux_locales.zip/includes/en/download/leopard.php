<h2>Leopard and Snow Leopard (Intel Only)</h2>
<p>Download the following file</p>
<p><a href='<?php echo $url; ?>/script_files/PlayOnMac/PlayOnMac_<?php include($racine."/script_files/version_mac.php"); ?>.dmg'>Click here to download PlayOnMac</a></p>
