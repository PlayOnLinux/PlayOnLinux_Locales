Hi,<br /><br />

This is a semi-automaic reply. This system has been made so that we do not have to repeat always the same things<br /><br />

Your topic has been closed because it does not respect <a href='/en/terms.html'>our terms of use</a><br /><br />

Please read the <a href='/en/terms.html'>terms of use</a>.<br /><br />

Feel free to ask if you have any other questions
