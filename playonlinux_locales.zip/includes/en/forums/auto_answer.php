Hi,<br /><br />

This is a semi-automaic reply. This system has been made so that we do not have to repeat always the same things<br /><br />

Your topic has been closed because it does not respect <a href='/en/terms.html'>our terms of use</a><br /><br />

Please read the <a href='/en/terms.html'>terms of use</a>.<br /><br />

You may also get more information here: <a href='http://wiki.playonlinux.com/index.php/FAQ#My_post_was_closed_with_a_semi-automated_reply.3F_What_did_I_break.3F'>F.A.Q. My post was closed with a semi-automated reply? What did I break?</a><br /><br />

Feel free to ask if you have any other questions
